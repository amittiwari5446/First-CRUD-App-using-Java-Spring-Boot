package com.example.crudapp.Controller;

import com.example.crudapp.DTO.StudentDTO;
import com.example.crudapp.Exception.StudentException;
import com.example.crudapp.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping(value="/school")
public class StudentAPI {
    @Autowired
    private StudentService studentService;

    @PostMapping(value="/students")
    public ResponseEntity<String> addStudent(@RequestBody StudentDTO studentDTO) throws StudentException{
        try{
            Integer studentId=studentService.addStudent(studentDTO);
            String successMessage="Student added successfully with studentId: "+studentId;
            return  new ResponseEntity<>(successMessage,HttpStatus.CREATED);
        }catch(Exception exception){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,exception.getMessage(),exception);
        }
    }

    @GetMapping(value="/students/{studentId}")
    public ResponseEntity<StudentDTO> getStudent(@PathVariable Integer studentId) throws StudentException{
        try{
            StudentDTO studentDTO=studentService.getStudentById(studentId);
            return new ResponseEntity<>(studentDTO, HttpStatus.OK);
        }catch (Exception exception){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,exception.getMessage(),exception);
        }
    }
    @GetMapping(value="/students")
    public ResponseEntity<List<StudentDTO>> getAllStudents() throws StudentException{
        try{
            List<StudentDTO> studentListDTO=studentService.getAllStudents();
            return new ResponseEntity<>(studentListDTO,HttpStatus.OK);
        }catch(Exception exception){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,exception.getMessage(),exception);
        }
    }

    @PutMapping(value="/students/{studentId}")
    public ResponseEntity<String> updateStudent(@PathVariable Integer studentId, StudentDTO studentDTO) throws StudentException{
        try{
            studentService.updateStudent(studentId,studentDTO);
            String successMessage="Student details are successfully updated with studentId: "+studentId;
            return new ResponseEntity<>(successMessage,HttpStatus.OK);
        }catch(Exception exception){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,exception.getMessage(),exception);
        }
    }

    @DeleteMapping(value="/students/{studentId}")
    public ResponseEntity<String> deleteStudent(@PathVariable Integer studentId) throws StudentException{
        try{
            studentService.deleteStudent(studentId);
            String successMessage="Student successfully deleted with studentId: "+studentId;
            return new ResponseEntity<>(successMessage,HttpStatus.OK);
        }catch(Exception exception){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,exception.getMessage(),exception);
        }
    }
}
