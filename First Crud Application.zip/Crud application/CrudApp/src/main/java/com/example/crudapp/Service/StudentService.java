package com.example.crudapp.Service;

import com.example.crudapp.DTO.StudentDTO;
import com.example.crudapp.Exception.StudentException;

import java.util.List;

public interface StudentService {
    public Integer addStudent(StudentDTO studentDTO) throws StudentException;
    public StudentDTO getStudentById(Integer studentId) throws StudentException;
    public List<StudentDTO> getAllStudents() throws StudentException;
    public void updateStudent(Integer studentId, StudentDTO studentDTO) throws StudentException;
    public void deleteStudent(Integer studentId) throws StudentException;
}
