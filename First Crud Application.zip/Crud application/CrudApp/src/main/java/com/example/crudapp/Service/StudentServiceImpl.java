package com.example.crudapp.Service;

import com.example.crudapp.DTO.StudentDTO;
import com.example.crudapp.Entity.Student;
import com.example.crudapp.Exception.StudentException;
import com.example.crudapp.Repository.StudentRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class StudentServiceImpl implements StudentService{

    @Autowired
    private StudentRepository studentRepository;
    @Override
    public Integer addStudent(StudentDTO studentDTO) throws StudentException {
        Student student=new Student();
        student.setStudentId(studentDTO.getStudentId());
        student.setName(studentDTO.getName());
        student.setPhone(studentDTO.getPhone());
        student.setStudentId(studentDTO.getStudentId());
        student.setEmail(studentDTO.getEmail());
        Student student2=studentRepository.save(student);
        return student2.getStudentId();
    }

    @Override
    public StudentDTO getStudentById(Integer studentId) throws StudentException {
        Optional<Student> optional=studentRepository.findById(studentId);
        Student student=optional.orElseThrow(()->new StudentException("No student found with given student Id"));
        StudentDTO studentDTO=new StudentDTO();
        studentDTO.setName(student.getName());
        studentDTO.setPhone(student.getPhone());
        studentDTO.setEmail(student.getEmail());
        studentDTO.setStudentId(student.getStudentId());
        return studentDTO;
    }

    @Override
    public List<StudentDTO> getAllStudents() throws StudentException {
        Iterable<Student> students=studentRepository.findAll();
        List<StudentDTO> students2=new ArrayList<>();
        students.forEach((student)->{
            StudentDTO studentDTO=new StudentDTO();
            studentDTO.setStudentId(student.getStudentId());
            studentDTO.setName(student.getName());
            studentDTO.setPhone(student.getPhone());
            studentDTO.setEmail(student.getEmail());
            students2.add(studentDTO);
        });
        if(students2.isEmpty()){
            throw new StudentException("No student found");
        }
        return students2;
    }

    @Override
    public void updateStudent(Integer studentId, StudentDTO studentDTO) throws StudentException {
        Optional<Student> optional=studentRepository.findById(studentId);
        Student student=optional.orElseThrow(()->new StudentException("No student found with given student Id"));
        student.setStudentId(studentDTO.getStudentId());
        student.setEmail(studentDTO.getEmail());
        student.setName(studentDTO.getName());
        student.setPhone(studentDTO.getPhone());
    }

    @Override
    public void deleteStudent(Integer studentId) throws StudentException {
        Optional<Student> optional=studentRepository.findById(studentId);
        optional.orElseThrow(()->new StudentException("No student found with given student Id"));
        studentRepository.deleteById(studentId);

    }
}
